# N45 overlay for `nxt_theme` (second pass)

This package keeps the original NexTash theme intact and layers a calmer N45 visual system on top.

## Focus of this pass

- More readable, less aggressive sidebar
- Cleaner workspace and dashboard cards
- Better list / report / table contrast
- More restrained form styling for CRM, Quotation, Opportunity, Customer, and accounting screens
- Cleaner login page
- Sidebar defaults to expanded for usability

## Files

- `nxt_theme/hooks.py`
- `nxt_theme/public/n45_overrides.bundle.scss`
- `nxt_theme/public/n45_overrides.bundle.js`
- `nxt_theme/public/images/shape.svg`
- `nxt_theme/public/images/n45-wordmark.svg`

## Apply

Copy these files into your existing `apps/nxt_theme/` tree, then rebuild:

```bash
bench build --app nxt_theme
bench clear-cache
bench restart
```

Then hard-refresh the browser.

## Notes

The upstream repo appears to be mostly bundled SCSS/JS with a single commit and hardcoded asset registration in `hooks.py`, so an overlay is safer than rewriting the base bundle.
