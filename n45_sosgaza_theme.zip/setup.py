from setuptools import setup, find_packages

with open("requirements.txt") as f:
    install_requires = f.read().strip().split("
")

from sosgaza_theme import __version__ as version

setup(
    name="sosgaza_theme",
    version=version,
    description="N45 branded themes for Frappe & ERPNext",
    author="N45 Technology Solutions",
    author_email="info@n45.org",
    packages=find_packages(),
    zip_safe=False,
    include_package_data=True,
    install_requires=install_requires,
)
