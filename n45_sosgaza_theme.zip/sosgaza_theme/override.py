import frappe

ALLOWED_THEMES = {"Dark", "Light", "Automatic", "n45_light", "n45_dark"}


@frappe.whitelist()
def switch_theme(theme):
    if theme in ALLOWED_THEMES:
        frappe.db.set_value("User", frappe.session.user, "desk_theme", theme)
