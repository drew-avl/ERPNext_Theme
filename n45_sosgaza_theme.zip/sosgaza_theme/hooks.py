from . import __version__ as app_version

app_name = "sosgaza_theme"
app_title = "N45 Theme"
app_publisher = "N45 Technology Solutions"
app_description = "N45 branded GitHub-inspired themes for Frappe & ERPNext"
app_email = "info@n45.org"
app_license = "MIT"
app_logo_url = "/assets/sosgaza_theme/img/logo.png"

website_context = {
    "favicon": "/assets/sosgaza_theme/img/icon.png",
    "splash_image": "/assets/sosgaza_theme/img/splash.jpg",
}

app_include_css = "sosgaza_theme.bundle.css"
app_include_js = ["sosgaza_theme.bundle.js"]

override_whitelisted_methods = {
    "frappe.core.doctype.user.user.switch_theme": "sosgaza_theme.override.switch_theme"
}
