frappe.provide("frappe.ui");

frappe.ui.ThemeSwitcher = class N45ThemeSwitcher extends frappe.ui.ThemeSwitcher {
    constructor() {
        super();
    }

    fetch_themes() {
        return new Promise((resolve) => {
            this.themes = [
                { name: "light", label: __("Frappe Light"), info: __("Default light theme") },
                { name: "dark", label: __("Timeless Night"), info: __("Default dark theme") },
                { name: "automatic", label: __("Automatic"), info: __("Use the system color mode") },
                { name: "n45_light", label: __("N45 Light"), info: __("GitHub-inspired light mode with N45 accents") },
                { name: "n45_dark", label: __("N45 Night"), info: __("GitHub-inspired dark mode with N45 accents") },
            ];
            resolve(this.themes);
        });
    }
};
