# N45 Theme for ERPNext / Frappe

A clean N45-branded fork of `ameerbaathar/sosgaza_theme`.

## What changed

- Removed the novelty themes and replaced them with **N45 Light** and **N45 Night**.
- Reworked the palette around the N45 blue mark with GitHub-like neutrals, tighter borders, restrained shadows, and compact controls.
- Updated the theme switcher so users can choose:
  - Frappe Light
  - Timeless Night
  - Automatic
  - N45 Light
  - N45 Night
- Replaced the bundled logo assets with N45 branding.

## Install

```bash
bench get-app <your fork or local path>
bench --site <your-site> install-app sosgaza_theme
bench build
bench clear-cache
```

Then switch the Desk theme from the user menu.

## Notes

- The package name remains `sosgaza_theme` so it can be dropped in as a direct fork.
- The custom themes are designed to feel closer to GitHub / Primer than a typical glossy ERP skin.
